# CoinDCX Bot Framework

This framework allows you to create a trading bot for CoinDCX to automate XRP/USDT trading using RSI, MACD, and Bollinger Bands.

## Setup Instructions

1. Replace `your_api_key` and `your_api_secret` in `main.py` with your CoinDCX API credentials.
2. Install the required Python libraries:
   ```
   pip install requests pandas ta
   ```
3. Run the bot:
   ```
   python main.py
   ```

## Features
- Fetch historical candlestick data for XRP/USDT.
- Calculate RSI, MACD, and Bollinger Bands indicators.
- Generate buy/sell signals based on technical analysis.
- Place market orders automatically based on signals.

## Disclaimer
This bot is for educational purposes only. Trade at your own risk.
