import requests
import hmac
import hashlib
import time
import pandas as pd
import ta

# Configuration
API_KEY = "your_api_key"
API_SECRET = "your_api_secret"
BASE_URL = "https://api.coindcx.com"

def create_signature(payload, secret):
    return hmac.new(
        bytes(secret, "utf-8"),
        bytes(payload, "utf-8"),
        hashlib.sha256
    ).hexdigest()

def get_candles(symbol, interval, limit=100):
    url = f"{BASE_URL}/market_data/candles"
    params = {
        "pair": symbol,
        "interval": interval,
        "limit": limit
    }
    response = requests.get(url, params=params)
    if response.status_code == 200:
        data = response.json()
        df = pd.DataFrame(data)
        df['close'] = pd.to_numeric(df['close'])
        return df
    else:
        print("Error fetching data:", response.text)
        return None

def add_indicators(df):
    # Calculate RSI
    df["rsi"] = ta.momentum.RSIIndicator(df["close"], window=14).rsi()

    # Calculate MACD
    macd = ta.trend.MACD(df["close"])
    df["macd"] = macd.macd()
    df["signal"] = macd.macd_signal()

    # Calculate Bollinger Bands
    bb = ta.volatility.BollingerBands(df["close"], window=20, window_dev=2)
    df["bb_upper"] = bb.bollinger_hband()
    df["bb_lower"] = bb.bollinger_lband()

    return df

def check_trade(df):
    latest_rsi = df["rsi"].iloc[-1]
    latest_macd = df["macd"].iloc[-1]
    latest_signal = df["signal"].iloc[-1]
    latest_close = df["close"].iloc[-1]
    bb_upper = df["bb_upper"].iloc[-1]
    bb_lower = df["bb_lower"].iloc[-1]

    if latest_rsi > 50 and latest_macd > latest_signal and latest_close > bb_upper:
        return "BUY"
    elif latest_rsi < 40 and latest_macd < latest_signal and latest_close < bb_lower:
        return "SELL"
    return "HOLD"

def place_order(symbol, side, quantity):
    url = f"{BASE_URL}/exchange/v1/orders/create"
    timestamp = int(time.time() * 1000)
    body = {
        "market": symbol,
        "side": side,
        "order_type": "market_order",
        "quantity": quantity,
        "timestamp": timestamp
    }
    signature = create_signature(str(body), API_SECRET)
    headers = {
        "X-AUTH-APIKEY": API_KEY,
        "X-AUTH-SIGNATURE": signature
    }
    response = requests.post(url, json=body, headers=headers)
    if response.status_code == 200:
        print(f"Order placed successfully: {response.json()}")
    else:
        print(f"Error placing order: {response.text}")

def main():
    while True:
        try:
            df = get_candles("XRPUSDT", "1m", limit=100)
            if df is not None:
                df = add_indicators(df)
                signal = check_trade(df)
                print("Trade Signal:", signal)

                if signal == "BUY":
                    place_order("XRPUSDT", "buy", 10)
                elif signal == "SELL":
                    place_order("XRPUSDT", "sell", 10)

            time.sleep(60)
        except Exception as e:
            print("Error:", e)

if __name__ == "__main__":
    main()
